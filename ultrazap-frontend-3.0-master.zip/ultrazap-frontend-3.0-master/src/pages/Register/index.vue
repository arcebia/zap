<template>
  <q-page class="flex flex-center">
    a
  </q-page>
</template>

<script>
export default {

}
</script>

<style>

</style>
