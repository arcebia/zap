import notify from '../js/notify'

export default ({ Vue }) => {
  Vue.prototype.$notify = notify
}
