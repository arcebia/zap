<template>
  <router-view />
</template>

<script>
export default {
  name: 'Frameless',

  data () {
    return {
      leftDrawerOpen: false
    }
  }
}
</script>
