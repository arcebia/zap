export default {
  all: null
}
