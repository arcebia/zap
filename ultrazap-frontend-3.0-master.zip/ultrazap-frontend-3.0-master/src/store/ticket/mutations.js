export function set (state, data) {
  state.all = data
}
