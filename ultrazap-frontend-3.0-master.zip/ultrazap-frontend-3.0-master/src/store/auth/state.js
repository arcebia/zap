export default {
  me: null
}
