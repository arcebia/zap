export function me (state, data) {
  state.me = data
}
