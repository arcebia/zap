'use strict'

/*
|--------------------------------------------------------------------------
| UserSeeder
|--------------------------------------------------------------------------
|
| Make use of the Factory instance to seed database with dummy data or
| make use of Lucid models directly.
|
*/

/** @type {import('@adonisjs/lucid/src/Factory')} */
const Factory = use('Factory')
const Database = use('Database')
const User = use('App/Models/User')
const Attendant = use('App/Models/Attendant')
const Sector = use('App/Models/Sector')
const AttendantSector = use('App/Models/AttendantSector')

const Client = use('App/Models/Client')
const Address = use('App/Models/Address')
const Admin = use('App/Models/Admin')
const Device = use('App/Models/Device')
const Role = use('Adonis/Acl/Role')

class AdminSeeder {

	async run () {
		// const trx = await Database.beginTransaction()

		// const admin = await Factory.model('App/Models/Admin').make()

		const userAdmin1 = await User.create({email: 'admin1@example.com', password: '@]PuJ*#7'}),
		 admin1= await Admin.create({user_id: userAdmin1.id, name: 'admin1' })

		const user1 = await User.create({email: 'client1@example.com', password: '@]PuJ*#7'}),
		 client1 = await Client.create({
			user_id: user1.id,
			phone: '5554321675432',
			manager: 'manager_name1',
			cpfCnpj: '000111-2233',
			name: 'company_name1'
		})
		await Device.create({
			client_id: client1.id,
			phone: "5554321675432",
			token: "",
		})
		add1 = await Address.create({
			city: 'city1',
			state: 'al',
			street: 'street 1',
			number: '1',
			neighborhood: 'neigh1',
			zipCode: '112233-44',
			client_id: client1.id
		}),
		sector1 = await Sector.create({name: 'suporte', client_id: client1.id}),

		user2 = await User.create({email: 'client2@example.com', password: '@]PuJ*#7'}),
		 client2 = await Client.create({
			user_id: user2.id,
			phone: '554535232322',
			manager: 'company_manager_name2',
			cpfCnpj: '0432342411-7333',
			name: 'company_name2'
		})
		await Device.create({
			client_id: client2.id,
			phone: "554535232322",
			token: "",
		})
		add2 = await Address.create({
			city: 'city2',
			state: 'al',
			street: 'street 2',
			number: '2',
			neighborhood: 'neigh2',
			zipCode: '112233-456',
			client_id: client2.id
		}),

		sector2 = await Sector.create({name: 'atendimento', client_id: client2.id}),
		

		user3 = await User.create({email: 'attendant1@example.com', password: '@]PuJ*#7'}),
		attendant1 = await Attendant.create({
			user_id: user3.id,
			client_id: client2.id,
			cpf: '000111'
		}),

		
		superAdmin = await User.create({email: 'super@admin.com', password: '@]PuJ*#7'})

		const roleSuperAdmin = new Role()
		roleSuperAdmin.name = 'SuperAdmin'
		roleSuperAdmin.slug = 'superAdmin'
		roleSuperAdmin.description = 'manage administrator users'
		await roleSuperAdmin.save()

		const roleAdmin = new Role()
		roleAdmin.name = 'Administrator'
		roleAdmin.slug = 'administrator'
		roleAdmin.description = 'manage administration privileges'
		await roleAdmin.save()

		const roleClientManager = new Role()
		roleClientManager.name = 'ClientManager'
		roleClientManager.slug = 'clientManager'
		roleClientManager.description = 'manage client manager privileges'
		await roleClientManager.save()

		const roleAttendant = new Role()
		roleAttendant.name = 'Attendant'
		roleAttendant.slug = 'attendant'
		roleAttendant.description = 'manage attendant privileges'
		await roleAttendant.save()

		await superAdmin.roles().attach([roleSuperAdmin.id])
		
		await userAdmin1.roles().attach([roleAdmin.id])
		await user1.roles().attach([roleClientManager.id])
		await user2.roles().attach([roleClientManager.id])
		
		await user3.roles().attach([roleAttendant.id])
		
	}
}

module.exports = AdminSeeder
