'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class AlterTicketSchema extends Schema {
  up () {
    this.alter('tickets', (table) => {
      // alter table
        table.timestamp('opened_at');
        table.timestamp('closed_at');
        table.integer('closed_by').unsigned()
        table.foreign('closed_by').references('id').on('users').onDelete('cascade')
    })
  }

  down () {
    this.alter('tickets', (table) => {
      // reverse alternations
        table.dropColumn('opened_at');
        table.dropColumn('closed_at');
        table.dropColumn('closed_by');
    })
  }
}

module.exports = AlterTicketSchema
