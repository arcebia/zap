'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class SectorAttendantSchema extends Schema {
  up () {
    this.create('sector_attendants', (table) => {
      table.increments()
      table.timestamps()
      table.integer('attendant_id').unsigned().index()
      table.foreign('attendant_id').references('id').on('attendants').onDelete('cascade')
      table.integer('sector_id').unsigned().index()
      table.foreign('sector_id').references('id').on('sectors').onDelete('cascade')
    })
  }

  down () {
    this.drop('sector_attendants')
  }
}

module.exports = SectorAttendantSchema
