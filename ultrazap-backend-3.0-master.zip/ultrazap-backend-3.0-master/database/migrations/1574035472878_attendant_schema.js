'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class AttendantSchema extends Schema {
  up () {
    this.create('attendants', (table) => {
      table.increments()
      table.integer('user_id').unsigned()
      table.foreign('user_id').references('id').on('users').onDelete('cascade')
      table.integer('client_id').unsigned()
      table.foreign('client_id').references('id').on('clients').onDelete('cascade')
      table.string('cpf').unique()
      table.string('name')
      table.timestamps()
    })
  }

  down () {
    this.drop('attendants')
  }
}

module.exports = AttendantSchema
