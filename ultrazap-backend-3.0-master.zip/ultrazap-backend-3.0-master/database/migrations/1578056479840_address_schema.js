'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class AddressSchema extends Schema {
  up () {
    this.create('addresses', (table) => {
      table.increments()
      table.integer('client_id')
      table.foreign('client_id').references('id').on('clients').onDelete('cascade')
      table.string('city')
      table.string('state')
      table.string('street')
      table.string('number')
      table.string('neighborhood')
      table.string('zipCode')
      table.timestamps()
    })
  }

  down () {
    this.drop('addresses')
  }
}

module.exports = AddressSchema
