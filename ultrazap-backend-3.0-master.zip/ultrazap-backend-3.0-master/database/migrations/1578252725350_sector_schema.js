'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class SectorSchema extends Schema {
  up () {
    this.create('sectors', (table) => {
      table.increments()
      table.timestamps()
      table.string('name')
      table.integer('client_id').unsigned()
      table.foreign('client_id').references('id').on('clients').onDelete('cascade')
    })
  }

  down () {
    this.drop('sectors')
  }
}

module.exports = SectorSchema
