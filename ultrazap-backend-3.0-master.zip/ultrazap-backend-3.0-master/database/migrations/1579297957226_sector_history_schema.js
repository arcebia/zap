'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class SectorHistorySchema extends Schema {
  up () {
    this.create('sector_histories', (table) => {
      table.increments()
      table.timestamps()
      table.string('note')
      table.integer('client_id').unsigned()
      table.foreign('client_id').references('id').on('clients').onDelete('cascade')
      table.integer('user_id').unsigned()
      table.foreign('user_id').references('id').on('users').onDelete('cascade')
      table.integer('ticket_id').unsigned()
      table.foreign('ticket_id').references('id').on('tickets').onDelete('cascade')
    })
  }

  down () {
    this.drop('sector_histories')
  }
}

module.exports = SectorHistorySchema
