'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class PasswordRecoverySchema extends Schema {
  up () {
    this.create('password_recovery', (table) => {
      table.increments()
      table.integer('user_id').unsigned()
      table.string('token')
      table.timestamps()
    })
  }

  down () {
    this.drop('password_recovery')
  }
}

module.exports = PasswordRecoverySchema
