'use strict'

const Schema = use('Schema')

class DeviceSchema extends Schema {
  up () {
    this.create('devices', table => {
      table.increments()
      table.integer('client_id').unsigned()
      table.foreign('client_id').references('id').on('clients')
      table.string('phone')
      table.string('token')
      table.string('origin').default("wablas")
      table.integer('status').default(1)
      table.timestamps()
    })
  }

  down () {
    this.drop('devices')
  }
}

module.exports = DeviceSchema
