'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class AlterConnectionSchema extends Schema {
  up () {
    this.alter('connections', (table) => {
      table.integer('device_id').unsigned()
      table.foreign('device_id').references('id').on('devices')
    })
  }

  down () {
    this.alter('connections', (table) => {
      table.dropColumn('device_id')
    })
  }
}

module.exports = AlterConnectionSchema
