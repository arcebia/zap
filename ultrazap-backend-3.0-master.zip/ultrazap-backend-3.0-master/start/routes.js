'use strict'

/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
|
| Http routes are entry points to your web application. You can create
| routes for different URL's and bind Controller actions to them.
|
| A complete guide on routing is available here.
| http://adonisjs.com/docs/4.1/routing
|
*/

/** @type {typeof import('@adonisjs/framework/src/Route/Manager')} */
const Route = use('Route')

Route.group(() => {
    Route.post('auth', 'api/v1/AuthController.login').middleware(['throttle']).validator('AuthLogin')
    Route.post('resetPass', 'api/v1/AuthController.resetPass').middleware(['throttle'])
    Route.post('submitNewPassword', 'api/v1/AuthController.submitNewPassword').middleware(['throttle'])
    Route.get('auth/me', 'api/v1/AuthController.me')//.middleware(['throttle', 'auth:jwt'])
    Route.post('auth/register/user', 'api/v1/AuthController.register').middleware(['throttle']).validator('AuthRegisterUser')
    Route.post('auth/register/client', 'api/v1/AuthController.registerClient').middleware(['throttle']).validator('AuthRegisterClient')

    Route.post('admin/get-all', 'api/v1/AdminController.getAllAdmin').middleware(['throttle'])
    Route.post('admin/register', 'api/v1/AdminController.registerAdmin').middleware(['throttle'])
    Route.post('admin/delete/:id', 'api/v1/AdminController.deleteById').middleware(['throttle'])
    Route.post('admin/update/:id', 'api/v1/AdminController.update').middleware(['throttle'])

    Route.post('client/get-all', 'api/v1/ClientController.getAll').middleware(['throttle'])
    Route.post('client/register', 'api/v1/ClientController.register').middleware(['throttle'])
    Route.post('client/toggleBlock', 'api/v1/ClientController.toggleBlockById').middleware(['throttle'])
    Route.post('client/delete/:id', 'api/v1/ClientController.deleteById').middleware(['throttle'])
    Route.post('client/update/:id', 'api/v1/ClientController.update').middleware(['throttle'])

    Route.post('sector/register', 'api/v1/SectorController.register').middleware(['throttle'])
    Route.post('sector/delete/:id', 'api/v1/SectorController.deleteById').middleware(['throttle'])
    Route.post('sector/update/:id', 'api/v1/SectorController.update').middleware(['throttle'])

    Route.post('attendant/register', 'api/v1/AttendantController.register').middleware(['throttle'])
    Route.post('attendant/delete/:id', 'api/v1/AttendantController.deleteById').middleware(['throttle'])
    Route.post('attendant/update/:id', 'api/v1/AttendantController.update').middleware(['throttle'])

    Route.get('tickets/', 'api/v1/TicketController.index').middleware(['throttle', 'auth:jwt'])
    Route.post('tickets/webhook/:token', 'api/v1/TicketController.webhook').middleware(['throttle'])
    Route.post('tickets/send', 'api/v1/TicketController.sendMessage').middleware(['throttle', 'auth:jwt']).validator('sendToTicket')
    Route.post('tickets/sendAttach', 'api/v1/TicketController.sendAttach').middleware(['throttle'])

    Route.get('connections/status', 'api/v1/ConnectionController.status').middleware(['throttle', 'auth:jwt'])
    Route.get('connections/create', 'api/v1/ConnectionController.create').middleware(['throttle', 'auth:jwt'])

    Route.post('whatsapp/callback/:phone', 'api/v1/WhatsappController.callback').middleware(['throttle'])
    Route.post('whatsapp/callback/:phone/media', 'api/v1/WhatsappController.mediaCallback').middleware(['throttle'])
    Route.get('whatsapp/callback/:phone/qr-code', 'api/v1/WhatsappController.cbQrCode').middleware(['throttle'])
    Route.get('whatsapp/qr-code', 'api/v1/WhatsappController.qrCode').middleware(['throttle', 'auth:jwt'])

    Route.get('attachs/:id', 'api/v1/AttachController.show')
    // .middleware(['throttle', 'auth:jwt'])

    Route.post('devices/create', 'api/v1/DeviceController.create').middleware(['throttle', 'auth:jwt'])
    Route.delete('devices/:id', 'api/v1/DeviceController.delete').middleware(['throttle', 'auth:jwt'])
    Route.patch('devices/:id', 'api/v1/DeviceController.update').middleware(['throttle', 'auth:jwt'])
    Route.get('devices', 'api/v1/DeviceController.list').middleware(['throttle', 'auth:jwt'])
    Route.get('devices/:id/qr-code', 'api/v1/DeviceController.getQrCode').middleware(['throttle', 'auth:jwt'])

    Route.get('test', 'api/v1/TestController.test')
}).prefix('api/v1')
