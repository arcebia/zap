'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class Client extends Model {

    connection () {
        return this.hasOne('App/Models/Connection')
    }

    devices () {
        return this.hasMany('App/Models/Device')
    }

    address () {
        return this.hasOne('App/Models/Address')
    }

    user () {
        return this.belongsTo('App/Models/User')
    }

    tickets () {
        return this.hasMany('App/Models/Ticket')
    }

    sectors () {
        return this.hasMany('App/Models/Sector')
    }

    attendants () {
        return this.hasMany('App/Models/Attendant')
    }
}

module.exports = Client
