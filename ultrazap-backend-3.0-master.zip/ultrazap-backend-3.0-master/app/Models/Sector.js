'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class Sector extends Model {
  static get table () {
    return 'sectors'
  }

  // attendants () {
  //   return this
  //     .hasToMany('App/Models/Attendant')
  //     .pivotModel('App/Models/AttendantSector')
  // }
}

module.exports = Sector
