const nodemailer = require("nodemailer")
const pug = require("pug")
const AWS = require('aws-sdk')
const path = require("path")

const SendEmail = async (to, subject, html, from) => {
    const transporter = nodemailer.createTransport({
        SES: new AWS.SES({ 
            apiVersion: '2010-12-01', 
            region: 'us-east-1',
            accessKeyId: process.env.SES_ACCESS_KEY,
            secretAccessKey: process.env.SES_SECRET_ACCESS_KEY, 
        })
    })

    transporter.sendMail({
        from: from || '"Ultrazap" <noreply@agenciatakeone.tech>',
        to, subject, html
    });
}

const RenderEmail = async (to, subject, htmlName, template, from) => {
    const transporter = nodemailer.createTransport({
        SES: new AWS.SES({ 
            apiVersion: '2010-12-01', 
            region: 'us-east-1',
            accessKeyId: process.env.SES_ACCESS_KEY,
            secretAccessKey: process.env.SES_SECRET_ACCESS_KEY, 
        })
    })
    
    const file = path.resolve(process.cwd(), `views/mails/${htmlName}.pug`);
    const html = pug.renderFile(file, template);
    let attachments = []
    if(template.file) {
        let attachment = {
            filename: template.file.name,
            path: template.file.path,
            contentType: 'application/pdf'
        }
        attachments.push(attachment)
    }
    return transporter.sendMail({
        from: from || '"Ultrazap" <noreply@agenciatakeone.tech>',
        to, subject, html, attachments
    });
}

module.exports = {
    SendEmail,
    RenderEmail,
}