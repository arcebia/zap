'use strict'

const Ticket = use('App/Models/Ticket');
const Message = use('App/Models/Message');
const Device = use('App/Models/Device');
const Client = use('App/Models/Client');
const axios = require('axios');
const fs = require('fs');
const AWS = require('aws-sdk');
const uniqid = require('uniqid');
const path = require('path');
const http = require('http');
const https = require('https');
const FileType = require('file-type');

const s3 = new AWS.S3({
    accessKeyId: process.env.AWS_KEY,
    secretAccessKey: process.env.AWS_SECRET,
    region: process.env.AWS_REGION
});

class TicketController {
  user;
  token;
  ticket;
  message;

  async index ({ auth, params, request, response }) {
    let user = await auth.getUser()
    let client = await user.client().fetch()

    let tickets = await client.tickets().with('messages').fetch()

    return tickets
  }

  async _upload(request){
      const self = this;
      const allowedExtensions = [
          '.doc', '.docx', '.pdf', '.odt', '.csv',
          '.ppt', '.pptx', '.xls', '.xlsx', '.mp3',
          '.ogg', '.jpg', '.jpeg', '.png', '.gif',
          '.mp4', '.mpeg'
      ];
      const data = request.input('body').split(';base64,');
      const type = data[0].substr(5);

      const buff = new Buffer(data[1], 'base64');
      const len = Buffer.byteLength(buff);

      const sizeMb = len / 1000000;
      if(sizeMb > 10){
          throw new Error(`O arquivo não pode ter mais de 10 MB`);
      }

      if(allowedExtensions.indexOf(path.extname(request.input('name'))) === -1){
          throw new Error(`Arquivo não permitido`);
      }

      const upload = await s3.upload({
          Bucket: process.env.AWS_BUCKET,
          Key: `${self.client.id}/${self.ticket.id}/` + uniqid() + '_' + request.input('name'),
          Body: buff,
          ACL: "public-read"
      }).promise();

      return {link: upload.Location, type: type}
  }

  async _saveMessage(upload){
      const self = this;

      self.message.client_id = self.client.id;
      self.message.ticket_id = self.ticket.id;
      self.message.from = self.user.id;
      self.message.origin = 'user';
      self.message.body = upload.link;
      self.message.type = upload.type;
      await self.message.save();

      return self.message;
  }

  async _sendImage(request, upload){
      const self = this;
      const ax = await axios.post(
          `${process.env.API_LINK}/api/send-image`,
          {phone: self.ticket.from, image: upload.link},
          {headers: { Authorization: self.token }},
      );

      if(!ax.data.status){ throw new Error(ax.data.message); }

      console.log(ax.config.data, ax.data);

      return await self._saveMessage(upload);
  }

  async _sendVideo(request, upload){
      const self = this;
      const ax = await axios.post(
          `${process.env.API_LINK}/api/send-video`,
          {phone: self.ticket.from, image: upload.link},
          {headers: { Authorization: self.token }},
      );

      if(!ax.data.status){ throw new Error(ax.data.message); }

      console.log(ax.config.data, ax.data);

      return await self._saveMessage(upload);

  }

  async _sendAttachment(request, upload){
      const self = this;
      const ax = await axios.post(
          `${process.env.API_LINK}/api/send-document`,
          {phone: self.ticket.from, image: upload.link},
          {headers: { Authorization: self.token }},
      );

      if(!ax.data.status){ throw new Error(ax.data.message); }

      console.log(ax.config.data, ax.data);

      return await self._saveMessage(upload);
  }

  async sendMessage ({ auth, params, request, response }) {
    const self = this;

    self.user = await auth.getUser();
    self.token = self.user.getToken();
    self.ticket = await Ticket.findOrFail(request.input('ticket_id'));
    self.client = await self.user.client().with('connection').fetch();
    self.client = self.client.toJSON();

    self.message = new Message();

    if(!request.input('blob')){
        // Se for uma mensagem normal
        try{
            const ax = await axios.post(
                `${process.env.API_LINK}/api/send-message`,
                {phone: self.ticket.from, message: request.input('body')},
                {headers: { Authorization: self.token }},
            );

            if(!ax.data.status){
                return response.status(500).send(ax.data.message);
            }

            console.log(ax.config.data, ax.data);

            self.message.client_id = self.client.id;
            self.message.ticket_id = self.ticket.id;
            self.message.from = self.user.id;
            self.message.origin = 'user';
            self.message.body = request.input('body');
            await self.message.save();

            return self.message;
        }catch (e) {
            return response.status(500).send(e);
        }
    }

    if(request.input('blob')){
      try{
          const upload = await self._upload(request);
          const type = upload.type.split('/');
          switch (type[0].toLowerCase()) {
              case 'image': return await self._sendImage(request, upload);
              case 'video': return await self._sendVideo(request, upload);
              default: return await self._sendAttachment(request, upload);
          }
      }catch (e) {
          return response.status(500).send(e);
      }
    }
  }

  // WebHook methods and helpers
  // SEMPRE CADASTRAR NO WEBHOOK DO WABLAS https://<NOSSA-API>/api/v1/tickets/webhook/<TOKEN DO CLIENTE>
  async webhook ({ params, request, response }) {
        const self = this;
        const token = params.token;
        const device = await Device.findBy('token', token);

        if(!device){
            return response.status(500).send(`Cliente não encontrado`);
        }

        const client_id = device.client_id;

        const id = request.input('id');                     //	string	Message ID like random string
        const phone = request.input('phone');               //	string	sender number, example: 62821144818
        const pushName = request.input('pushName');         //	string	sender name example: Peter
        const message = request.input('message');           //	string	content of message
        const groupId = request.input('groupId');           //	string	Group ID if message coming from group whatsapp, example: 6282111444818-84267713. So your Group ID is 84267713
        const groupSubject = request.input('groupSubject'); //  string	Group Name
        const image = request.input('image');               //	string	name of image
        const file = request.input('file');                 //  string	name of file like document or video
        const url = request.input('url');                   //  string  URL from image / document / video
        // -----------------------------------------------------------  https://wablas.com/documentation

        const ticket = await Ticket.findOrCreate({
            'client_id': client_id,
            'from': phone
        });

        if(!ticket){
            return response.status(500).send(`Ticket não encontrado`);
        }

        if(!ticket.opened_at){
            ticket.opened_at = new Date();
            await ticket.save();
        }

        if(message){
            const msg = new Message();
            msg.client_id = client_id;
            msg.ticket_id = ticket.id;
            msg.from = phone;
            msg.body = message;
            await msg.save();
        }

        if(url){
            const attachment = new Message();
            attachment.client_id = client_id;
            attachment.ticket_id = ticket.id;
            attachment.from = phone;
            await self._uploadWebHook(attachment, url)
        }

        return {"success": true};
    }

    _uploadWebHook(msg, url){
      return new Promise(resolve => {
          let buffer;

          if(url.indexOf('http://') > -1){
              http.get(url, function(res) {
                  let data = [];

                  res.on('data', function(chunk) {
                      data.push(Buffer.from(chunk, 'binary'));
                  }).on('end', async function() {
                      buffer = Buffer.concat(data);
                      const mime = await FileType.fromBuffer(buffer);
                      //=> {ext: 'png', mime: 'image/png'}

                      const upload = await s3.upload({
                          Bucket: process.env.AWS_BUCKET,
                          Key: `${msg.client_id}/${msg.ticket_id}/` + uniqid() + '.' + mime.ext,
                          Body: buffer,
                          ACL: "public-read"
                      }).promise();

                      msg.type = mime.mime;
                      msg.body = upload.Location;
                      resolve(msg.save());
                  });
              });
          }

          if(url.indexOf('https://') > -1){
              https.get(url, (res) => {
                  let data = [];

                  res.on('data', (chunk) => {
                      data.push(Buffer.from(chunk, 'binary'));
                  });

                  res.on('end', async () => {
                      buffer = Buffer.concat(data);
                      const mime = await FileType.fromBuffer(buffer);
                      //=> {ext: 'png', mime: 'image/png'}

                      const upload = await s3.upload({
                          Bucket: process.env.AWS_BUCKET,
                          Key: `${msg.client_id}/${msg.ticket_id}/` + uniqid() + '.' + mime.ext,
                          Body: buffer,
                          ACL: "public-read"
                      }).promise();

                      msg.type = mime.mime;
                      msg.body = upload.Location;
                      resolve(msg.save());
                  });
              });
          }
      })
    }
}

module.exports = TicketController
