'use strict'

const User = use('App/Models/User'),
 Admin = use('App/Models/Admin'),
 PasswordRecovery = use('App/Models/PasswordRecovery'),
 Attendant = use('App/Models/Attendant'),
 Client = use('App/Models/Client'),
 Sector = use('App/Models/Sector'),
 Device = use('App/Models/Device'),
 randomString = require('crypto-random-string'),
 {RenderEmail} = use('App/Services/MailService')

const Database = use('Database')

class AuthController {

    constructor(){
        this.passRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})")
    }

	async register ({ auth, params, request, response }) {
        let query = new User()
        
        if(!this.passRegex.test(request.input('password'))) 
            return {error: 'Senha deve conter no mínimo 1 letra maiúscula, 1 letra minúscula, 1 número e 1 símbolo e que tenha ao mínimo 8 caracteres'}
        
        query.email = request.input('email')
        query.password = request.input('password')

        await query.save()

        return query.id
    }

	

	async registerClient ({ auth, params, request, response }) {
        const trx = await Database.beginTransaction()
        try{
            let client = new Client()
            let device = new Device()

            client.user_id = request.input('user_id')
            client.name = request.input('name')
            client.phone = request.input('phone')

            await client.save(trx)

            device.client_id = client.id
            device.phone = client.phone
            device.token = null
            await device.save(trx)

            await trx.commit()
            return {client, device}
        }catch(err){
            await trx.rollback()
            return {error: err.message}
        }
    }

    async login ({ auth, params, request, response }) {
        
        try {
            let password = request.input('password')

            const email = request.input('email'),
            login = await auth.attempt(email, password),
            user = await User.findBy('email', email),
            roles = await user.getRoles()

            await user
                .loadMany([
                    'admin',
                    'attendant',
                    'client',
                    'roles'
                ])

            if (user.$relations.client){
                if (user.$relations.client.blocked){
                    return { error: 'Usuário bloqueado' }
                }

                await user.$relations.client.loadMany(['sectors','attendants'])
                
                if (user.$relations.client.$relations.attendants.rows.length > 0) {
                    for(let att of user.$relations.client.$relations.attendants.rows){
                        await att.loadMany(['user','sectors'])
                        
                    }
                }
            }
            if (user.$relations.attendant) {
                await user.$relations.attendant.load('client')
                if (user.$relations.attendant.$relations.client.blocked){
                    return { error: 'Usuário bloqueado' }
                }
            }

            return {login, user, roles, token: login.token}   
        } catch (error) {
            console.log(error)
            return { error }
        }
        

    }

    async submitNewPassword({ auth, params, request, response }) {

        
        try {
            let password = request.input('password')
            
            if (this.passRegex.test(password)){
            
                let passRec = await PasswordRecovery.findBy('token', request.input('token'))

                if (passRec){

                    let user = await User.findBy('id', passRec.user_id)
                    user.password = request.input('password')
                    user.save()
                    passRec.delete()
                    return {success:'new password saved'}

                } else {
                    return {error: 'Token não encontrado'}
                }

            } else {
                return {error: 'Senha deve conter no mínimo 1 letra maiúscula, 1 letra minúscula, 1 número e 1 símbolo e que tenha ao mínimo 8 caracteres'}
            }

        } catch (error) {
            console.log(error)
        }

    }

    async resetPass({ auth, params, request, response }) {
        try {
            
            const user = await User.findBy('email', request.input('email'))
            await PasswordRecovery.query().where('user_id', user.id).delete()
            const { token } = await PasswordRecovery.create({
                user_id: user.id,
                token: randomString({ length: 40 })
              })

            let result = await RenderEmail(user.email , 
                "ULTRAZAP - ALTERAÇÃO DE SENHA", 
                "passwordRecove", 
                {
                    url: process.env.PASSWORD_RECOVERY_URL,
                    token
                }
            )

            console.log(result)

            return {success:'email send'}
        } catch (error) {
            console.log(error)
        }

    }

    async me ({ auth, params, request, response }) {
        
        try {
            
            const query = await auth.getUser()
    
            await query
                .loadMany([
                    'admin',
                    'attendant',
                    'client',
                    'devices'
                ])
    
            return query

        } catch (error) {
            console.log(error)
            return error
        }
    }

}

module.exports = AuthController
