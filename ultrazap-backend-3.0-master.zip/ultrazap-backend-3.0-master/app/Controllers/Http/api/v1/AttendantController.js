'use strict'

const Attendant = use('App/Models/Attendant'),
User = use('App/Models/User'),
Sector = use('App/Models/Sector'),
AttendantSector = use('App/Models/AttendantSector')

class AttendantController {

  async register({ auth, params, request, response }) {
    
    try {
      
      let attendantData = request.all()

      if (attendantData.email && attendantData.password && attendantData.name && attendantData.clientId > -1 && attendantData.sectors.length > 0) {

        let attendant = new Attendant(),
         user = new User()

        user.email = attendantData.email
        user.password = attendantData.password

        await user.save()

        attendant.setRelated('user', user)

        attendant.name = attendantData.name
        attendant.cpf = attendantData.cpf
        attendant.client_id = attendantData.clientId
        attendant.user_id = user.id

        let secs = []
        for(let sec of attendantData.sectors){
          secs.push(await Sector.findBy('id',sec.id)) 
        }
        
        await attendant.save()

        if (secs.length > 0){
          attendant.setRelated('sectors', secs)
          for(let sector of secs){
            let attSec = new AttendantSector()
            attSec.attendant_id = attendant.id
            attSec.sector_id = sector.id
            attSec.save()
          }
        }

        return { attendant }

      } else {
        return { error: 'Algum paramêtro faltando' }
      }
    } catch (error) {
      console.log(error)
      return JSON.stringify(error) 
    }

  }

  async update({ auth, params, request, response }) {
    try {

      let attendantData = request.all()

      if (attendantData.user.email && attendantData.name && attendantData.client_id > -1 && attendantData.sectors.length > 0) {

        let attendant = await Attendant.findBy('id', attendantData.id),
         user = await User.findBy('id', attendantData.user_id)

         user.email = attendantData.user.email
         await user.save()

        attendant.setRelated('user', user)

        attendant.name = attendantData.name
        attendant.cpf = attendantData.cpf

        let secs = []
        for(let sec of attendantData.sectors){
          secs.push(await Sector.findBy('id',sec.id)) 
        }
        
        await attendant.save()

        await attendant.load('sectors')

        for(let sec of attendant.$relations.sectors.rows){
          await attendant.sectors().detach([sec.id])
            // await AttendantSector.query().where('id', sec.id).delete()
          // await attSector.delete()
        }

        if (secs.length > 0){
          delete attendant.$relations.sectors
          attendant.setRelated('sectors', secs)
          for(let sector of secs){
            let attSec = new AttendantSector() 
            attSec.attendant_id = attendant.id
            attSec.sector_id = sector.id
            await attSec.save()
          }
        }
        
        return { attendant }

      } else {
        return { error: 'Algum paramêtro faltando' }
      }
      
    } catch (error) {
      console.log(error)
      return { error: JSON.stringify(error) }
    }
  }

  async deleteById({ auth, params, request, response }) {

    
    let id = request.input('id')
    if (id > -1) {
      await Attendant.query().where('id', id).delete()

      return { success: 'Exclusão efetuada' }
    } else {
      return { error: 'Faltando paramêtro id' }
    }
  }

}

module.exports = AttendantController
