'use strict'

const User = use('App/Models/User')
const Admin = use('App/Models/Admin')
const Role = use('Adonis/Acl/Role')

class AdminController {

  constructor() {
    this.passRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})")
  }

  async deleteById({ auth, params, request, response }) {
    
    let id = request.input('id')
    if (id) {
      let admin = await Admin.findBy('id', id),
        user = await User.findBy('id', admin.user_id)

      admin.delete()
      user.delete()

      return { success: 'Exclusão efetuada' }

    } else {
      return { error: 'Faltando paramêtro id' }
    }
  }

  async getAllAdmin({ auth, params, request, response }) {

    let admins = await Admin.query().fetch()

    for (let admin of admins.rows) {
      await admin.load(['user'])
    }

    return { admins }
  }

  async registerAdmin({ auth, params, request, response }) {
    try {
      let email = request.input('email'),
        name = request.input('name'),
        password = request.input('password')

      if (email && password && name) {

        if (this.passRegex.test(password)){

          let newUser = new User(),
  
            roleAdmin = await Role.findBy('slug', 'administrator')
  
          newUser.email = email
          newUser.password = password
  
          await newUser.save()
  
          await newUser.roles().attach([roleAdmin.id])
  
          let newAdmin = new Admin()
  
          newAdmin.user_id = newUser.id
          newAdmin.name = name
  
          await newAdmin.save()
  
          await newAdmin.load(['user'])
  
          return { success: newAdmin }

        } else {
          return {error: 'Senha deve conter no mínimo 1 letra maiúscula, 1 letra minúscula, 1 número e 1 símbolo e que tenha ao mínimo 8 caracteres'}
        }


      } else {
        return { error: 'Algum paramêtro faltando' }
      }
    } catch (error) {
      return { error }
    }

  }

  async update({ auth, params, request, response }) {
    
    try {
      let email = request.input('email'),
        name = request.input('name'),
        id = request.input('id')

      if (email && id && name) {

        let admin = await Admin.findBy('id', id),
        user = await User.findBy('id', admin.user_id)

        admin.name = name

        user.email = email

        await user.save()

        await admin.save()

        await admin.load(['user'])

        return { success: admin }

      } else {
        return { error: 'Algum paramêtro faltando' }
      }
    } catch (error) {
      return { error }
    }

  }
}

module.exports = AdminController
