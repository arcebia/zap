'use strict'

const User = use('App/Models/User')
const Client = use('App/Models/Client')
const Address = use('App/Models/Address')
const Role = use('Adonis/Acl/Role')
const Database = use('Database')

// const Attendant = use('App/Models/Attendant')
// const client = use('App/Models/client')

class ClientController {

  constructor() {
    
  }

  async deleteById({ auth, params, request, response }) {
    
    let id = request.input('id')
    if (id || id > -1) {
      let client = await Client.findBy('id', id),
        user = await User.findBy('id', client.user_id),
        address = await Address.findBy('client_id', client.id)

      await client.delete()
      await user.delete()
      await address.delete()

      return { success: 'Exclusão efetuada' }

    } else {
      return { error: 'Faltando paramêtro id' }
    }
  }

  async toggleBlockById({ auth, params, request, response }) {
    
    
    let id = request.input('id'), action = request.input('action')
    
    if (id > -1) {
      let client = await Client.findBy('id', id), message

      if (action === 'block'){
        client.blocked = true
        message = 'Bloqueio efetuado'
      } else {
        client.blocked = false
        message = 'Bloqueio retirado'
      }

      await client.save()

      return { success: message }

    } else {
      return { error: 'Faltando paramêtro id' }
    }
  }

  async getAll({ auth, params, request, response }) {

    let clients = await Client.query().fetch()

    for (let client of clients.rows) {
      try {
        await client.loadMany([
          'user', 'address', 'connection', 'tickets'
        ])
      } catch (error) {
        console.error(error)
        return { error }
      }
    }

    return { companies: clients }
  }

  async register({ auth, params, request, response }) {
    const trx = await  Database.beginTransaction()
    try {
      let email = request.input('email'),
        name = request.input('name'),
        phone = request.input('phone'),
        cpfCnpj = request.input('cpfCnpj'),
        manager = request.input('manager'),
        password = request.input('password')

      if (email && password && name && manager && cpfCnpj) 
        throw new Error('Algum paramêtro faltando')
      if (!this.passRegex.test(password))
        throw new Error('Senha deve conter no mínimo 1 letra maiúscula, 1 letra minúscula, 1 número e 1 símbolo e que tenha ao mínimo 8 caracteres')

      let newUser = new User(),

        roleClient = await Role.findBy('slug', 'clientManager')

      newUser.email = email
      newUser.password = password

      await newUser.save(trx)

      await newUser.roles().attach([roleClient.id], trx)

      let newClient = new Client()

      newClient.user_id = newUser.id
      newClient.name = name
      newClient.cpfCnpj = cpfCnpj
      newClient.manager = manager

      phone ? newClient.phone = phone : null

      await newClient.save(trx)


      let address = new Address(), addInfo = request.input('address')
      addInfo.city && addInfo.city.length > 0 ? address.city = addInfo.city : address.city = ''
      addInfo.neighborhood && addInfo.neighborhood.length > 0 ? address.neighborhood = addInfo.neighborhood : address.neighborhood = ''
      addInfo.number && addInfo.number.length > 0 ? address.number = addInfo.number : address.number = ''
      addInfo.state && addInfo.state.length > 0 ? address.state = addInfo.state : address.state = ''
      addInfo.street && addInfo.street.length > 0 ? address.street = addInfo.street : address.street = ''
      addInfo.zipCode && addInfo.zipCode.length > 0 ? address.zipCode = addInfo.zipCode : address.zipCode = ''
      address.client_id = newClient.id

      await address.save(trx)

      await newClient.loadMany(['user','address'])
  
      await trx.commit()
      return { success: newClient }
    } catch (error) {
      await trx.rollback()
      return {error: error.message}
    }

  }

  async update({ auth, params, request, response }) {
    
    try {
      
      let user =  request.input('user'),
      name = request.input('name'),
      phone = request.input('phone'),
      cpfCnpj = request.input('cpfCnpj'),
      manager = request.input('manager')

      if (user.email && name && manager && cpfCnpj) {

          let oldUser = await User.findBy('id', user.id)
  
          oldUser.email = user.email
  
          await oldUser.save()
  
          let oldClient = await Client.findBy('id', request.input('id'))
  
          oldClient.name = name
          oldClient.cpfCnpj = cpfCnpj
          oldClient.manager = manager

          phone ? oldClient.phone = phone : null
  
          await oldClient.save()

          let addInfo = request.input('address'),
           address = await Address.findBy('id', addInfo.id)

          addInfo.city && addInfo.city.length > 0 ? address.city = addInfo.city : address.city = ''
          addInfo.neighborhood && addInfo.neighborhood.length > 0 ? address.neighborhood = addInfo.neighborhood : address.neighborhood = ''
          addInfo.number && addInfo.number.length > 0 ? address.number = addInfo.number : address.number = ''
          addInfo.state && addInfo.state.length > 0 ? address.state = addInfo.state : address.state = ''
          addInfo.street && addInfo.street.length > 0 ? address.street = addInfo.street : address.street = ''
          addInfo.zipCode && addInfo.zipCode.length > 0 ? address.zipCode = addInfo.zipCode : address.zipCode = ''

          await address.save()
  
          await oldClient.loadMany(['user','address'])
  
          return { success: oldClient }

      } else {
        return { error: 'Algum paramêtro faltando' }
      }

    } catch (error) {
      return { error }
    }

  }
}

module.exports = ClientController
