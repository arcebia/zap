'use strict'

const Device = use('App/Models/Device')
const Env = use('Env')
const axios = use('axios')

class DeviceController {
    async list ({ auth, params, request, response }) {
      let targets = Env.get('CONNECTION_TARGET').split(',')
      let user = await auth.getUser()
      let client = await user.client().fetch()
      let devices = await client.devices().fetch()

      return devices
    }
    
    async create ({ auth, params, request, response }) {
      let targets = Env.get('CONNECTION_TARGET').split(',')
      let user = await auth.getUser()
      let client = await user.client().fetch()

      if (!client) return response.status(401).send('Não autorizado')
      if(!request.input('phone')) return response.status(400).send('Informe o whatsapp')
      if(!request.input('token')) return response.status(400).send('Informe o token')

      let device = new Device()
      device.client_id = client.id
      device.phone = request.input('phone')
      device.token = request.input('token')
      await device.save()

      return device
    }
    
    async delete ({ auth, params, request, response }) {
      let targets = Env.get('CONNECTION_TARGET').split(',')
      let user = await auth.getUser()
      let client = await user.client().fetch()
      let device = await Device.findBy('id', params.id)

      if (!client || client.id !== device.client_id) return response.status(401).send('Não autorizado')
      
      await device.delete()

      return response.status(201).send('Deletado')
    }
    
    async update ({ auth, params, request, response }) {
      let targets = Env.get('CONNECTION_TARGET').split(',')
      let user = await auth.getUser()
      let client = await user.client().fetch()
      let device = await Device.findBy('id', params.id)

      if (!client || client.id !== device.id) return response.status(401).send('Não autorizado')
      
      if(request.input('token')) device.token = request.input('token')
      if(request.input('phone')) device.phone = request.input('phone')
      
      await device.save()

      return response.status(201).send('Deletado')
    }

    async getQrCode ({ auth, params, request, response }) {
      let user = await auth.getUser()
      let client = await user.client().fetch()
      let device = await Device.findBy('id', params.id)

      if (!client || client.id !== device.id) return response.status(401).send('Não autorizado')
      if(!device.token) return response.status(400).send('Informe o token gerar o qr code')

      return `${process.env.API_LINK}/api/generate/qr.php?token=${device.token}&url=aHR0cHM6Ly9jb25zb2xlLndhYmxhcy5jb20=`
    }
}

module.exports = DeviceController
