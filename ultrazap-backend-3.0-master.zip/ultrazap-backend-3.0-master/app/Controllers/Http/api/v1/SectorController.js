'use strict'

const Sector = use('App/Models/Sector')

// const User = use('App/Models/User')
// const Client = use('App/Models/Client')
// const Role = use('Adonis/Acl/Role')
// const Attendant = use('App/Models/Attendant')
// const client = use('App/Models/client')

class SectorController {

  constructor() {
    
  }

  async deleteById({ auth, params, request, response }) {
    
    let id = request.input('id')
    if (id > -1) {
      let sector = await Sector.findBy('id', id)

      await sector.delete()

      return { success: 'Exclusão efetuada' }
    } else {
      return { error: 'Faltando paramêtro id' }
    }
  }

  async register({ auth, params, request, response }) {
    try {
      
      let name = request.input('sector'),
        companyId = request.input('companyId')

      if (name && companyId) {

          let sector = await Sector.create({
            name,
            client_id: companyId
          })

  
          return { success: `Setor ${name} criado`, sector }

      } else {
        return { error: 'Algum paramêtro faltando' }
      }
    } catch (error) {
      console.log(error)
      return JSON.stringify(error) 
    }

  }

  async update({ auth, params, request, response }) {
    
    try {
      
      let id =  request.input('id'),
      name = request.input('name')

      if (id > -1 && name) {

          let sector = await Sector.findBy('id', id)
  
          sector.name = name
  
          await sector.save()
  
  
          return { success: sector }

      } else {
        return { error: 'Algum paramêtro faltando' }
      }

    } catch (error) {
      console.log(error)
      return { error }
    }

  }
}

module.exports = SectorController
