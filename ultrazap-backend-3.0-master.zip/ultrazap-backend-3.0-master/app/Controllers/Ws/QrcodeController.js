'use strict'

class QrcodeController {
  constructor ({ socket, request }) {
    this.socket = socket
    this.request = request
  }
}

module.exports = QrcodeController
